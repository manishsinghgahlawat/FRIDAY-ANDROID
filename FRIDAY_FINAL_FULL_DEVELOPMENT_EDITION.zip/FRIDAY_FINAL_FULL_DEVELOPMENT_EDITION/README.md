# FRIDAY — Final Consolidated Development Source

Target: Android 10+; intended device iQOO 12 / Android 16.  
Personal data store: phone-local Room database. No application backend, cloud database, or automatic cloud backup is configured. GitHub Actions is optional and used only for building the APK.

## Gemini AI Brain
The app includes an API Settings screen. Paste a newly created Gemini API key there; it is encrypted at rest with Android Keystore AES-GCM. The key is not embedded in source code. The app calls Gemini `generateContent` over HTTPS.

**Privacy warning:** Gemini is a cloud model. Every prompt sent to it is transmitted to Google's servers. Keep personal/private data out of Gemini prompts if you require strict on-device-only processing. An API key in a client app cannot be made impossible to extract; restrict and rotate it.

## Build
Use JDK 17, Android SDK 36 and Gradle 8.13:
`gradle :app:assembleDebug`

Or upload the *contents* of this folder to the root of a private GitHub repository (including `.github`) and run Actions → FRIDAY Android Build.

## Truthful implementation status
This is a consolidated development source with a working Gemini REST client/settings path, local database foundation, safety controller, approval token mechanism, bounded agent scheduler, voice launch/TTS foundation, browser/email intents, and Android integration contracts. It has **not** been built or device-tested here. Read `docs/KNOWN_LIMITS.md` and `docs/FINAL_SCOPE.md`.

It is not yet a finished production FRIDAY: local LLM runtime/model, always-on wake word, 3D avatar assets/renderer, Gmail OAuth provider, production client hunter, full SAF file manager, complete self-upgrade, full multi-agent role implementations and device verification remain integration/development work.

Never commit API keys. Do not reuse a key previously pasted into chat; revoke it and create a fresh restricted key.
