package com.codezero.friday

import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.util.concurrent.ConcurrentHashMap

/**
 * Bounded coroutine scheduler, not 15 independent intelligent agents by itself.
 * Actual agent implementations must be registered by application modules.
 */
class AgentCoordinator(private val safety:SafetyController, dispatcher:CoroutineDispatcher=Dispatchers.Default) {
 private val scope=CoroutineScope(SupervisorJob()+dispatcher)
 private val permits=Semaphore(15)
 private val jobs=ConcurrentHashMap<String,Job>()
 suspend fun submit(id:String,action:String,work:suspend()->Unit) {
  safety.requireAllowed(action)
  val job=scope.launch {
   permits.withPermit { safety.requireAllowed(action); work() }
  }
  jobs[id]=job
  job.invokeOnCompletion { jobs.remove(id) }
 }
 fun cancelAll() { jobs.values.forEach { it.cancel() }; jobs.clear() }
 fun activeCount()=jobs.size
 fun close()=scope.cancel()
}
