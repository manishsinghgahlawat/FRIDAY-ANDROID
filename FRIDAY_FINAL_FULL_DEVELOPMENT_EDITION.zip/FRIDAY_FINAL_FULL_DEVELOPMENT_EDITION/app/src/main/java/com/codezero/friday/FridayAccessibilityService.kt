package com.codezero.friday
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
class FridayAccessibilityService:AccessibilityService() {
 override fun onAccessibilityEvent(event:AccessibilityEvent?) {}
 override fun onInterrupt() {}
}
