package com.codezero.friday

import android.content.Context
import androidx.room.*

@Entity(tableName="memories")
data class MemoryEntry(@PrimaryKey(autoGenerate=true) val id:Long=0, val text:String, val createdAt:Long=System.currentTimeMillis())
@Entity(tableName="tasks")
data class TaskEntry(@PrimaryKey(autoGenerate=true) val id:Long=0, val title:String, val state:String="PENDING", val createdAt:Long=System.currentTimeMillis())
@Entity(tableName="audit")
data class AuditEntry(@PrimaryKey(autoGenerate=true) val id:Long=0, val action:String, val reason:String, val createdAt:Long=System.currentTimeMillis())

@Dao interface MemoryDao {
 @Insert suspend fun insert(entry:MemoryEntry)
 @Query("SELECT * FROM memories ORDER BY createdAt DESC LIMIT 500") suspend fun latest():List<MemoryEntry>
}
@Dao interface TaskDao {
 @Insert suspend fun insert(entry:TaskEntry):Long
 @Query("SELECT * FROM tasks WHERE state='PENDING' ORDER BY createdAt") suspend fun pending():List<TaskEntry>
 @Query("UPDATE tasks SET state=:state WHERE id=:id") suspend fun setState(id:Long,state:String)
}
@Dao interface AuditDao {
 @Insert suspend fun insert(entry:AuditEntry)
 @Query("SELECT * FROM audit ORDER BY createdAt DESC LIMIT :limit") suspend fun latest(limit:Int):List<AuditEntry>
}
@Database(entities=[MemoryEntry::class,TaskEntry::class,AuditEntry::class],version=1,exportSchema=true)
abstract class FridayDatabase:RoomDatabase() {
 abstract fun memoryDao():MemoryDao
 abstract fun taskDao():TaskDao
 abstract fun auditDao():AuditDao
 companion object {
  @Volatile private var INSTANCE:FridayDatabase?=null
  fun get(context:Context):FridayDatabase = INSTANCE ?: synchronized(this) {
   INSTANCE ?: Room.databaseBuilder(context.applicationContext,FridayDatabase::class.java,"friday_local.db")
    .build().also { INSTANCE=it }
  }
 }
}
