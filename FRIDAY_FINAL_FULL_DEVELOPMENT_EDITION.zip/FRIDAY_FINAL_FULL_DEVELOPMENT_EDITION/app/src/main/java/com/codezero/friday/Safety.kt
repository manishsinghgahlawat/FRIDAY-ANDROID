package com.codezero.friday

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class SafetyController(private val db:FridayDatabase) {
 @Volatile private var stopped=false
 private val mutex=Mutex()
 suspend fun emergencyStop(reason:String)=mutex.withLock {
  stopped=true
  db.auditDao().insert(AuditEntry(action="EMERGENCY_STOP",reason=reason))
  db.taskDao().pending().forEach { db.taskDao().setState(it.id,"CANCELLED_BY_STOP") }
 }
 suspend fun resetAfterExplicitUserConfirmation()=mutex.withLock {
  stopped=false
  db.auditDao().insert(AuditEntry(action="EMERGENCY_RESET",reason="Explicit reset in app"))
 }
 fun isStopped()=stopped
 suspend fun requireAllowed(action:String) {
  if(stopped) {
   db.auditDao().insert(AuditEntry(action="BLOCKED:$action",reason="Emergency Stop active"))
   error("Emergency Stop is active")
  }
 }
 suspend fun audit(action:String,reason:String)=db.auditDao().insert(AuditEntry(action,reason))
}
data class ApprovalToken(val id:String=UUID.randomUUID().toString(),val type:String,val exactPayload:String,val expiresAt:Long=System.currentTimeMillis()+120000)
class ApprovalManager {
 private val tokens=ConcurrentHashMap<String,ApprovalToken>()
 fun request(type:String,payload:String)=ApprovalToken(type=type,exactPayload=payload).also { tokens[it.id]=it }
 fun consume(id:String,type:String,payload:String):Boolean {
  val t=tokens.remove(id) ?: return false
  return t.expiresAt>=System.currentTimeMillis() && t.type==type && t.exactPayload==payload
 }
 fun revokeAll()=tokens.clear()
}
class EmergencyStop(private val safety:SafetyController,private val approvals:ApprovalManager,private val agents:AgentCoordinator) {
 suspend fun trigger(reason:String) { approvals.revokeAll(); agents.cancelAll(); safety.emergencyStop(reason) }
}
