package com.codezero.friday

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat

enum class FridayPermission(val value:String) {
 MICROPHONE(Manifest.permission.RECORD_AUDIO),
 NOTIFICATIONS(Manifest.permission.POST_NOTIFICATIONS)
}
class PermissionManager(private val context:Context,private val db:FridayDatabase) {
 fun granted(p:FridayPermission)=ContextCompat.checkSelfPermission(context,p.value)==PackageManager.PERMISSION_GRANTED
 suspend fun audit(p:FridayPermission) {
  db.auditDao().insert(AuditEntry(action="PERMISSION:${p.name}",reason=if(granted(p)) "granted" else "not granted"))
 }
}
