package com.codezero.friday

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

data class BrainReply(val text:String,val model:String)

class GeminiBrain(private val secrets:SecretStore) {
 private val http=OkHttpClient.Builder()
  .connectTimeout(20,TimeUnit.SECONDS).readTimeout(60,TimeUnit.SECONDS).build()

 suspend fun ask(prompt:String, model:String="gemini-2.5-flash"):BrainReply = withContext(Dispatchers.IO) {
  require(prompt.isNotBlank()) { "Prompt is empty" }
  val key=secrets.readGeminiKey() ?: error("Gemini API key is not configured in FRIDAY Settings")
  val body=JSONObject().put("contents",
   org.json.JSONArray().put(JSONObject().put("parts",org.json.JSONArray().put(JSONObject().put("text",prompt)))))
   .toString().toRequestBody("application/json; charset=utf-8".toMediaType())
  val request=Request.Builder()
   .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
   .addHeader("x-goog-api-key",key)
   .post(body).build()
  http.newCall(request).execute().use { response ->
   val payload=response.body?.string().orEmpty()
   if(!response.isSuccessful) error("Gemini API error ${response.code}: ${payload.take(500)}")
   val json=JSONObject(payload)
   val text=json.optJSONArray("candidates")?.optJSONObject(0)
    ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text")
    ?: error("Gemini returned no text")
   BrainReply(text,model)
  }
 }
}
