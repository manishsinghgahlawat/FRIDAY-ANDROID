package com.codezero.friday

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import java.io.File
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import java.security.KeyStore

enum class AvatarMode { IDLE, LISTENING, THINKING, SPEAKING, SUCCESS, ERROR }
data class AvatarState(val mode:AvatarMode,val mouthOpen:Float=0f,val gazeX:Float=0f,val gazeY:Float=0f)
interface AvatarRenderer { fun load(modelPath:String):Boolean; fun draw(state:AvatarState); fun close() }
interface WakeWordEngine { suspend fun start(onWake:()->Unit):Boolean; fun stop() }
data class SkillManifest(val id:String,val version:String,val signed:Boolean,val permissions:Set<String>)
class SkillRegistry {
 private val skills=mutableMapOf<String,SkillManifest>()
 fun register(m:SkillManifest):Boolean { if(!m.signed || m.id.isBlank()) return false; skills[m.id]=m; return true }
 fun all()=skills.values.toList()
}
data class BrainPrompt(val text:String,val language:String="hi-IN")
interface LocalLlmProvider { suspend fun isReady():Boolean; suspend fun generate(prompt:BrainPrompt):String }
class LocalBrain(private val provider:LocalLlmProvider?) {
 suspend fun answer(p:BrainPrompt)=if(provider?.isReady()==true) provider.generate(p) else "Local LLM model is not installed."
}
class PhoneSettingsLauncher(private val context:Context) {
 fun accessibility()=context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}
class FridayRecoveryWorker(c:Context,p:WorkerParameters):CoroutineWorker(c,p) {
 override suspend fun doWork():Result = try {
  val db=FridayDatabase.get(applicationContext)
  db.auditDao().insert(AuditEntry(action="RECOVERY_START",reason="App startup recovery worker"))
  db.taskDao().pending().forEach { db.taskDao().setState(it.id,"NEEDS_REVIEW") }
  Result.success()
 } catch(_:Exception) { Result.retry() }
}
object LocalEncryptedExport {
 private const val ALIAS="friday_export_key"
 private fun key():SecretKey {
  val ks=KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
  (ks.getKey(ALIAS,null) as? SecretKey)?.let { return it }
  val kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore")
  kg.init(KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
   .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build())
  return kg.generateKey()
 }
 fun encryptToFile(file:File,data:ByteArray) {
  val c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE,key())
  file.outputStream().use { it.write(c.iv); it.write(c.doFinal(data)) }
 }
}
