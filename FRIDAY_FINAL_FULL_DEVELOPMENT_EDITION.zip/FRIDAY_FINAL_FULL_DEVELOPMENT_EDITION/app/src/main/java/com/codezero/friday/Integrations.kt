package com.codezero.friday

import android.content.Context
import android.content.Intent
import android.net.Uri

object ExternalIntegrations {
 fun webSearch(context:Context,q:String) {
  context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?q="+Uri.encode(q))))
 }
 fun composeEmail(context:Context,to:String="",subject:String="",body:String="") {
  val i=Intent(Intent.ACTION_SENDTO,Uri.parse("mailto:")).apply {
   putExtra(Intent.EXTRA_EMAIL,arrayOf(to)); putExtra(Intent.EXTRA_SUBJECT,subject); putExtra(Intent.EXTRA_TEXT,body)
  }
  context.startActivity(Intent.createChooser(i,"Choose email app"))
 }
}
interface GmailGateway {
 suspend fun authorize():Boolean
 suspend fun search(query:String):List<MailSummary>
 suspend fun createDraft(to:String,subject:String,body:String):String
 suspend fun send(draftId:String,approvalToken:String):Boolean
}
data class MailSummary(val id:String,val sender:String,val subject:String,val snippet:String)
interface ProspectProvider { suspend fun search(query:String,region:String):List<Prospect> }
data class Prospect(val name:String,val website:String?,val publicContact:String?,val source:String)
