package com.codezero.friday

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.util.Locale

class MainActivity:ComponentActivity(),TextToSpeech.OnInitListener {
 private lateinit var db:FridayDatabase
 private lateinit var secrets:SecretStore
 private lateinit var gemini:GeminiBrain
 private lateinit var tts:TextToSpeech
 private val mic=registerForActivityResult(ActivityResultContracts.RequestPermission()) { if(it) startSpeech() }
 override fun onCreate(savedInstanceState:Bundle?) {
  super.onCreate(savedInstanceState)
  db=FridayDatabase.get(this); secrets=SecretStore(this); gemini=GeminiBrain(secrets); tts=TextToSpeech(this,this)
  val safety=SafetyController(db); val approvals=ApprovalManager(); val agents=AgentCoordinator(safety)
  lifecycleScope.launch {
   db.auditDao().insert(AuditEntry(action="APP_START",reason="FRIDAY opened"))
   db.taskDao().pending().forEach { db.taskDao().setState(it.id,"NEEDS_REVIEW_AFTER_RESTART") }
  }
  setContent {
   MaterialTheme(colorScheme=darkColorScheme(primary=Color(0xFF35C8F2),background=Color(0xFF07111F),surface=Color(0xFF102238),onSurface=Color.White)) {
    var apiKey by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("FRIDAY ready. Add Gemini key in Settings to use cloud AI.") }
    var prompt by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }
    var logs by remember { mutableStateOf(listOf<AuditEntry>()) }
    var stop by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { logs=db.auditDao().latest(30) }
    Scaffold { pad ->
     LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
      item { Text("FRIDAY",style=MaterialTheme.typography.headlineLarge,color=Color(0xFF35C8F2)); Text("FULL DEVELOPMENT EDITION · LOCAL-FIRST",color=Color.LightGray); Text(status) }
      item { Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
       Button(onClick={ showSettings=!showSettings }) { Text("API Settings") }
       Button(onClick={ mic.launch(Manifest.permission.RECORD_AUDIO) }) { Text("Speak") }
       Button(onClick={ lifecycleScope.launch { EmergencyStop(safety,approvals,agents).trigger("Dashboard emergency stop"); stop=true; status="EMERGENCY STOP ACTIVE"; logs=db.auditDao().latest(30) } },colors=ButtonDefaults.buttonColors(containerColor=Color.Red)) { Text("EMERGENCY STOP") }
      } }
      if(showSettings) item {
       Card { Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
        Text("Gemini API Key")
        OutlinedTextField(value=apiKey,onValueChange={apiKey=it},label={Text("Paste new Gemini key")},singleLine=true)
        Button(onClick={
         runCatching { secrets.saveGeminiKey(apiKey); apiKey=""; status="Gemini key encrypted and saved on this phone." }
          .onFailure { status="Could not save key: ${it.message}" }
        }) { Text("Save securely on this phone") }
        OutlinedButton(onClick={ secrets.deleteGeminiKey(); status="Gemini key deleted from this phone." }) { Text("Delete key") }
        Text("Gemini prompts are sent to Google servers. Do not send private data unless you accept that.",color=Color(0xFFFFCC80))
       } }
      }
      item {
       OutlinedTextField(value=prompt,onValueChange={prompt=it},label={Text("Ask FRIDAY / Gemini")},modifier=Modifier.fillMaxWidth())
       Button(onClick={
        lifecycleScope.launch {
         status="Contacting Gemini…"
         try { val r=gemini.ask(prompt); answer=r.text; status="Gemini replied using ${r.model}"; db.auditDao().insert(AuditEntry(action="GEMINI_REQUEST",reason="User submitted a prompt")) }
         catch(e:Exception) { status="AI error: ${e.message}" }
         logs=db.auditDao().latest(30)
        }
       }) { Text("Ask Gemini") }
       Text(answer)
      }
      item {
       Card { Column(Modifier.padding(12.dp)) {
        Text("Safety status",style=MaterialTheme.typography.titleLarge)
        Text(if(stop) "STOPPED — manual reset required" else "Armed")
        Button(onClick={ lifecycleScope.launch { safety.resetAfterExplicitUserConfirmation(); stop=false; status="Emergency Stop manually reset." } },enabled=stop) { Text("Manual reset") }
       } }
      }
      item { Text("Recent local audit log",style=MaterialTheme.typography.titleLarge) }
      items(logs) { e -> Text("${e.createdAt} · ${e.action} · ${e.reason}",color=Color.LightGray) }
     }
    }
   }
  }
 }
 private fun startSpeech() {
  if(!SpeechRecognizer.isRecognitionAvailable(this)) return
  val r=SpeechRecognizer.createSpeechRecognizer(this)
  val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
   putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
   putExtra(RecognizerIntent.EXTRA_LANGUAGE,"hi-IN")
  }
  r.startListening(i)
 }
 override fun onInit(status:Int) { if(status==TextToSpeech.SUCCESS) tts.language=Locale("hi","IN") }
 override fun onDestroy() { if(::tts.isInitialized) { tts.stop(); tts.shutdown() }; super.onDestroy() }
}
