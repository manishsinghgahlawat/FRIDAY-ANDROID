package com.codezero.friday

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Encrypts the Gemini API key at rest with an Android Keystore AES-256-GCM key.
 * A key embedded in a distributed client can still be extracted at runtime; use a
 * restricted, quota-limited key and rotate it. Never commit a real key to source control.
 */
class SecretStore(context:Context) {
 private val prefs=context.getSharedPreferences("friday_secrets",Context.MODE_PRIVATE)
 private val alias="friday_gemini_aes_key"
 private fun secretKey():SecretKey {
  val ks=KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
  (ks.getKey(alias,null) as? SecretKey)?.let { return it }
  val gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore")
  gen.init(KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
   .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
   .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
   .setKeySize(256).build())
  return gen.generateKey()
 }
 fun saveGeminiKey(value:String) {
  require(value.trim().isNotEmpty()) { "API key cannot be empty" }
  val cipher=Cipher.getInstance("AES/GCM/NoPadding")
  cipher.init(Cipher.ENCRYPT_MODE,secretKey())
  val encrypted=cipher.doFinal(value.trim().toByteArray(Charsets.UTF_8))
  val encoded=Base64.encodeToString(cipher.iv,Base64.NO_WRAP)+"."+Base64.encodeToString(encrypted,Base64.NO_WRAP)
  prefs.edit().putString("gemini_key",encoded).apply()
 }
 fun readGeminiKey():String? = runCatching {
  val raw=prefs.getString("gemini_key",null) ?: return null
  val parts=raw.split(".")
  val iv=Base64.decode(parts[0],Base64.NO_WRAP)
  val cipher=Cipher.getInstance("AES/GCM/NoPadding")
  cipher.init(Cipher.DECRYPT_MODE,secretKey(),GCMParameterSpec(128,iv))
  String(cipher.doFinal(Base64.decode(parts[1],Base64.NO_WRAP)),Charsets.UTF_8)
 }.getOrNull()
 fun deleteGeminiKey() { prefs.edit().remove("gemini_key").apply() }
}
