# Known limits — read before calling this production-ready

1. This project has not been compiled or tested on a physical iQOO 12 / Android 16 device in this environment.
2. Gemini API key can be stored encrypted locally, but a key used by a distributed client app can be extracted by a determined attacker. Restrict quotas, restrict API access where possible, monitor usage and rotate keys. A secure proxy would require a backend and conflicts with the user's no-backend rule.
3. Gemini is cloud AI: each prompt/context sent to it leaves the phone and is processed by Google. Local database storage does not make cloud inference private.
4. Full local AI requires a selected runtime and model weights compatible with device RAM/storage/GPU.
5. Wake word requires an on-device model, foreground microphone service, battery and OS testing.
6. 3D avatar/lip sync requires a licensed model asset and renderer such as a compatible 3D engine; none is bundled.
7. Gmail requires Google OAuth consent, client configuration, token lifecycle, Gmail API implementation and verification.
8. Client Hunter needs a compliant public-data provider, parsing, source citations, rate limits and deduplication implementation.
9. Android's standard APIs do not let ordinary apps intercept every Power Button press. Use in-app emergency stop or supported OEM/system shortcut.
10. Full file management must use Android Storage Access Framework and user-granted URI permissions; broad filesystem access is not assumed.
11. Payments are not automated. The app must never initiate a payment without the user operating a trusted payment app and explicitly approving.
12. The 15-slot scheduler is concurrency infrastructure, not 15 completed autonomous AI agents.
13. Self-upgrade must use signed releases, integrity checks and user approval; automatic silent self-install is restricted by Android.
14. Database recovery handles local database reopening and marks interrupted tasks for review; it cannot roll back external side effects already completed by Gmail/payment/other apps.
15. The current dashboard is a functional development UI, not the final cinematic holographic avatar UI.
