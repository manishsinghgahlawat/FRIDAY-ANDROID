# FRIDAY Final Scope — complete module inventory

This source consolidates the Android app foundation and all requested module boundaries. It is not a claim that all external integrations/assets are operational.

## AI and intelligence
- Gemini cloud AI brain: API-key settings UI, encrypted local key storage using Android Keystore, REST generateContent request.
- Local AI provider interface for future offline LLM runtime.
- Truth-oriented response assessment contract.
- Local Room memory foundation.

## Voice and avatar
- Android SpeechRecognizer launch path and TTS initialization.
- Wake-word engine interface; always-on wake-word runtime/model not bundled.
- Avatar renderer interface, state model and lip-sync data contract; no 3D asset/renderer bundled.

## Phone and automation
- Accessibility service shell requiring explicit enablement.
- Permission status/audit foundation.
- Approval token manager with exact payload binding and expiry.
- Emergency Stop cancels registered agent jobs, revokes approvals and blocks subsequent actions routed through SafetyController.
- Android does not allow normal apps to intercept arbitrary Power-button presses; no false claim of global power-key capture.

## Agents and work
- Bounded 15-worker coroutine scheduler.
- Prospect provider interface and local deduplication boundary.
- Browser search and email composer intents.
- Gmail gateway contract; OAuth/API provider not configured.
- File/export and task/recovery foundations.
- Signed skill manifest registry; no dynamic code loading.

## Privacy and storage
- Room local database.
- Android backup disabled.
- Gemini API key encrypted at rest with Android Keystore.
- Gemini prompts sent to Google are cloud processed. Do not send sensitive/private data if strict on-device-only processing is required.
- No application backend or cloud database configured.
